<?php
include_once'./core/boot.php';
if($_SERVER['REQUEST_METHOD'] ==='post'){
}
if($_SERVER['REQUEST_METHOD'] ==='Get'){
    $produtId = $_GET['id'];
    $produt = get_product($productId);
    include_once './view/_detail.php';
}